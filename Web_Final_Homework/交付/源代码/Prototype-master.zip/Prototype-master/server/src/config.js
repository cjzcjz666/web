export const config = {
    database: 'prototype',
    username: 'root',
    password: 'cjz121720',
    host: 'bj-cdb-3h9trbt4.sql.tencentcdb.com',
    port: 60212,
}
