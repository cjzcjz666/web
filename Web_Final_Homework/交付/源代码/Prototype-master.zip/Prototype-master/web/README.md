### 详情
* 项目依赖 node.js 12
* 服务启动的端口为 8081 ，可在 package.json 中修改

### npm scripts

* npm install    安装依赖
* npm run start  启动开发服务
* npm run build && npm run serve 开发完成后启动服务

### 后端接口配置
* 在 src/request.js 中, 可以指定需要访问的后端接口

### 修改分枝 修改分枝2

### cjzz 修改三